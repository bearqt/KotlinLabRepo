class Vet {
    fun treatAnimal(animal: Animal) {
        animal.makeNoise()
        animal.eat()
        animal.sleep()
    }
}